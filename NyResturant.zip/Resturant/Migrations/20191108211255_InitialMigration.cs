﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Resturant.Migrations
{
    public partial class InitialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

            //migrationBuilder.AddColumn<int>(
            //    name: "Age",
            //    table: "Person",
            //    defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
